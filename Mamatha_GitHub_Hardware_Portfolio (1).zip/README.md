# Mamatha Bollinedi — Hardware Engineering Portfolio

This is my personal hardware engineering portfolio website.

## Focus Areas
- Hardware Engineering
- Manufacturing Engineering
- Automation
- Solar Cell Module Packaging
- Thin-Film Solar Cell Research
- MATLAB and LabVIEW Projects
- Instrumentation and Troubleshooting

## How to Publish
1. Create a GitHub repository named `yourusername.github.io`
2. Upload `index.html`
3. Go to Settings → Pages
4. Select Deploy from branch → main
5. Open `https://yourusername.github.io`
